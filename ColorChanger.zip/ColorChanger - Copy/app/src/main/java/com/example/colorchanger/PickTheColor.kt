package com.example.colorchanger

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView

class PickTheColor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pick_the_color)
        findViewById<TextView>(R.id.ColorBox).setBackgroundColor(Color.rgb(0, 0, 0))
        focusListener()

    }

    /*
    Method needs EditText/SeekBar, gives EditText?/SeekBar?

    private var redBox: EditText? = null
    private var greenBox: EditText? = null
    private var blueBox: EditText? = null
    private var redSeek: SeekBar? = null
    private var greenSeek: SeekBar? = null
    private var blueSeek: SeekBar? = null

     */


    /*
    program tries to find these views before actually creating them, causing the program to crash

    var redBox = findViewById<EditText>(R.id.RedValueBox)
    var greenBox = findViewById<EditText>(R.id.GreenValueBox)
    var blueBox = findViewById<EditText>(R.id.GreenValueBox)
    var redSeek = findViewById<SeekBar>(R.id.seekBarR)
    var greenSeek = findViewById<SeekBar>(R.id.seekBarG)
    var blueSeek = findViewById<SeekBar>(R.id.seekBarB)
         */

    fun allDone(view : View)
    {
        val intent = Intent(this, PickTheColor::class.java)
        intent.putExtra("ColorPickResult", findViewById<EditText>(R.id.RedValueBox).text.toString() + findViewById<EditText>(R.id.GreenValueBox).text.toString() +  findViewById<EditText>(R.id.BlueValueBox).text.toString())
        setResult(RESULT_OK, intent)
        finish()
    }

    private fun focusListener() {

        var redBox = findViewById<EditText>(R.id.RedValueBox)
        var greenBox = findViewById<EditText>(R.id.GreenValueBox)
        var blueBox = findViewById<EditText>(R.id.BlueValueBox)
        var redSeek = findViewById<SeekBar>(R.id.seekBarR)
        var greenSeek = findViewById<SeekBar>(R.id.seekBarG)
        var blueSeek = findViewById<SeekBar>(R.id.seekBarB)

        findViewById<EditText>(R.id.RedValueBox).setOnFocusChangeListener { _, hasFocus ->
            if(hasFocus)

            else {
                updateTextbox(redBox, redSeek)
            }
            /*

            Old code kept for reference in case I ever wanted to see how I initially got it to work

            else {
                if(findViewById<EditText>(R.id.RedValueBox).text.toString() == "")
                {
                    findViewById<EditText>(R.id.RedValueBox).setText("0")
                }
            if(Integer.parseInt(findViewById<EditText>(R.id.RedValueBox).text.toString()) > 255)
            {
                findViewById<SeekBar>(R.id.seekBarR).progress = 255
                findViewById<EditText>(R.id.RedValueBox).setText("255")
            }
            else {
                findViewById<SeekBar>(R.id.seekBarR).progress =
                    Integer.parseInt(findViewById<EditText>(R.id.RedValueBox).text.toString())
            }
            }

             */
        }

            findViewById<EditText>(R.id.GreenValueBox).setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus)
                else{
                    updateTextbox(redBox, redSeek)
                }
            }

        findViewById<EditText>(R.id.BlueValueBox).setOnFocusChangeListener { _, hasFocus ->
            if(hasFocus)

            else{
                updateTextbox(redBox, redSeek)
            }
        }
        findViewById<SeekBar>(R.id.seekBarR)?.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                updateProgressBar(redSeek, redBox)

                /*
                Again kept to see how I initially figured out the problems

                findViewById<EditText>(R.id.RedValueBox).setText(p0?.progress.toString())
                var red = 0
                if(findViewById<EditText>(R.id.RedValueBox).text.toString() == "")
                    red = 0
                else
                    red = Integer.parseInt(findViewById<EditText>(R.id.RedValueBox).text.toString())
                var green = 0
                if(findViewById<EditText>(R.id.GreenValueBox).text.toString() == "")
                    green = 0
                else
                    green = Integer.parseInt(findViewById<EditText>(R.id.GreenValueBox).text.toString())
                var blue = 0
                if(findViewById<EditText>(R.id.BlueValueBox).text.toString() == "")
                    blue = 0
                else
                    blue = Integer.parseInt(findViewById<EditText>(R.id.BlueValueBox).text.toString())
                Log.v("debug", "$red $green $blue")
                findViewById<TextView>(R.id.ColorBox).setBackgroundColor(Color.rgb(red, green, blue))

                 */
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "started tracking")
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "stopped tracking")
            }
        })

        findViewById<SeekBar>(R.id.seekBarG)?.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                updateProgressBar(greenSeek, greenBox)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "started tracking")
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "stopped tracking")
            }
        })

        findViewById<SeekBar>(R.id.seekBarB)?.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                updateProgressBar(blueSeek, blueBox)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "started tracking")
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                //Log.v("debug", "stopped tracking")
            }
        })

    }

    fun updateProgressBar(seekBar: SeekBar, editText: EditText) {
        editText.setText(seekBar.progress.toString())
        updateColors()
    }

    fun updateColors()
    {
        var colorBox = findViewById<TextView>(R.id.ColorBox)
        var redSeek = findViewById<SeekBar>(R.id.seekBarR)
        var greenSeek = findViewById<SeekBar>(R.id.seekBarG)
        var blueSeek = findViewById<SeekBar>(R.id.seekBarB)

        colorBox.setBackgroundColor(Color.rgb(redSeek.progress, greenSeek.progress, blueSeek.progress))
    }

    fun updateTextbox(editText: EditText, seekBar: SeekBar)
    {
            var temp = editText.text.toString()
            var parsed = 0
            if(temp != "")
                parsed = Integer.parseInt(temp)
            if(parsed > 255)
            {
                editText.setText("255")
                seekBar.progress = 255
            }
            else {
                seekBar.progress = parsed
            }
        updateColors()

    }


    //Log.v("debug", "made it to the second page")

}
